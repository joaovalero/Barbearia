const form_login = document.getElementById("form_log");
form_login.addEventListener('submit', e => {
    e.preventDefault()
})

function redirecionar_usuario (){
    window.location.href = "../menu/index.html"
}

function changeClass() {
    document.getElementsByClassName("erro_label_d")[0].className = "erro_label";
    document.getElementsByClassName("erro_label_d")[0].className = "erro_label";
}

function limpaErro() {
    document.getElementsByClassName("erro_label")[0].className = "erro_label_d";
    document.getElementsByClassName("erro_label")[0].className = "erro_label_d";
}

function valida_form (){
    if(document.getElementById("email").value.length != 0 || document.getElementById("senha").value.length != 0){
    redirecionar_usuario();
        } else {
            changeClass();
            if(document.getElementById("email").value.length != 0 || document.getElementById("senha").value.length != 0){
                redirecionar_usuario();
            }
        }
    }
