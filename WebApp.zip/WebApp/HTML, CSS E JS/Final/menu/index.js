function call_insight() {
    alert("Operação concluída");
}